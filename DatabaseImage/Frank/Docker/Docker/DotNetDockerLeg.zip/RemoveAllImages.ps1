docker rmi $(docker image list --quiet)
