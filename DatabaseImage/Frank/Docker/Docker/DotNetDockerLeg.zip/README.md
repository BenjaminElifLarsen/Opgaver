# DotNetCoreDockerDemo

A demo of how to use Docker for building and deploying Dot Net Core apps